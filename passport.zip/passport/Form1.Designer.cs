﻿namespace passport
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.SearchPass = new System.Windows.Forms.Button();
            this.searchApp = new System.Windows.Forms.Button();
            this.delpass = new System.Windows.Forms.Button();
            this.delapp = new System.Windows.Forms.Button();
            this.updpass = new System.Windows.Forms.Button();
            this.updapp = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.Clear_app = new System.Windows.Forms.Button();
            this.phone = new System.Windows.Forms.MaskedTextBox();
            this.adapp = new System.Windows.Forms.Button();
            this.dob = new System.Windows.Forms.DateTimePicker();
            this.gender = new System.Windows.Forms.ListBox();
            this.adress = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.Clear_pas = new System.Windows.Forms.Button();
            this.number = new System.Windows.Forms.MaskedTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.apid = new System.Windows.Forms.TextBox();
            this.adpas = new System.Windows.Forms.Button();
            this.expiration = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.type = new System.Windows.Forms.ListBox();
            this.label14 = new System.Windows.Forms.Label();
            this.issue = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.phone_chan = new System.Windows.Forms.MaskedTextBox();
            this.СlearChanApp = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.TextBox();
            this.ChanApp = new System.Windows.Forms.Button();
            this.dob_chan = new System.Windows.Forms.DateTimePicker();
            this.gender_chan = new System.Windows.Forms.ListBox();
            this.adress_chan = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.name_chan = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label29 = new System.Windows.Forms.Label();
            this.apid_chan = new System.Windows.Forms.TextBox();
            this.ClearChanPass = new System.Windows.Forms.Button();
            this.number_chan = new System.Windows.Forms.MaskedTextBox();
            this.ChanPass = new System.Windows.Forms.Button();
            this.issue_chan = new System.Windows.Forms.DateTimePicker();
            this.label23 = new System.Windows.Forms.Label();
            this.type_chan = new System.Windows.Forms.ListBox();
            this.label24 = new System.Windows.Forms.Label();
            this.expiration_chan = new System.Windows.Forms.DateTimePicker();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.exit = new System.Windows.Forms.Button();
            this.info = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(1, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(858, 636);
            this.tabControl1.TabIndex = 18;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.Info;
            this.tabPage1.Controls.Add(this.info);
            this.tabPage1.Controls.Add(this.exit);
            this.tabPage1.Controls.Add(this.SearchPass);
            this.tabPage1.Controls.Add(this.searchApp);
            this.tabPage1.Controls.Add(this.delpass);
            this.tabPage1.Controls.Add(this.delapp);
            this.tabPage1.Controls.Add(this.updpass);
            this.tabPage1.Controls.Add(this.updapp);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.dataGridView2);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(850, 610);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Таблицы";
            // 
            // SearchPass
            // 
            this.SearchPass.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.SearchPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SearchPass.Location = new System.Drawing.Point(204, 312);
            this.SearchPass.Name = "SearchPass";
            this.SearchPass.Size = new System.Drawing.Size(70, 20);
            this.SearchPass.TabIndex = 33;
            this.SearchPass.Text = "Найти";
            this.SearchPass.UseVisualStyleBackColor = false;
            this.SearchPass.Click += new System.EventHandler(this.SearchPass_Click);
            // 
            // searchApp
            // 
            this.searchApp.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.searchApp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.searchApp.Location = new System.Drawing.Point(204, 5);
            this.searchApp.Name = "searchApp";
            this.searchApp.Size = new System.Drawing.Size(70, 20);
            this.searchApp.TabIndex = 32;
            this.searchApp.Text = "Найти";
            this.searchApp.UseVisualStyleBackColor = false;
            this.searchApp.Click += new System.EventHandler(this.SearchApp_Click);
            // 
            // delpass
            // 
            this.delpass.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.delpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delpass.Location = new System.Drawing.Point(356, 312);
            this.delpass.Name = "delpass";
            this.delpass.Size = new System.Drawing.Size(70, 20);
            this.delpass.TabIndex = 31;
            this.delpass.Text = "Удалить";
            this.delpass.UseVisualStyleBackColor = false;
            this.delpass.Click += new System.EventHandler(this.Delpass_Click);
            // 
            // delapp
            // 
            this.delapp.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.delapp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.delapp.Location = new System.Drawing.Point(356, 5);
            this.delapp.Name = "delapp";
            this.delapp.Size = new System.Drawing.Size(70, 20);
            this.delapp.TabIndex = 30;
            this.delapp.Text = "Удалить";
            this.delapp.UseVisualStyleBackColor = false;
            this.delapp.Click += new System.EventHandler(this.Delapp_Click);
            // 
            // updpass
            // 
            this.updpass.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.updpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.updpass.Location = new System.Drawing.Point(280, 312);
            this.updpass.Name = "updpass";
            this.updpass.Size = new System.Drawing.Size(70, 20);
            this.updpass.TabIndex = 29;
            this.updpass.Text = "Обновить";
            this.updpass.UseVisualStyleBackColor = false;
            this.updpass.Click += new System.EventHandler(this.Updpass_Click);
            // 
            // updapp
            // 
            this.updapp.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.updapp.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.updapp.Location = new System.Drawing.Point(280, 5);
            this.updapp.Name = "updapp";
            this.updapp.Size = new System.Drawing.Size(70, 20);
            this.updapp.TabIndex = 28;
            this.updapp.Text = "Обновить";
            this.updapp.UseVisualStyleBackColor = false;
            this.updapp.Click += new System.EventHandler(this.Updapp_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(8, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Поиск:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(8, 316);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Поиск:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(60, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(138, 20);
            this.textBox1.TabIndex = 23;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(60, 313);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(138, 20);
            this.textBox2.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(731, 312);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 17);
            this.label7.TabIndex = 21;
            this.label7.Text = "Паспорта";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(722, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 17);
            this.label8.TabIndex = 20;
            this.label8.Text = "Заявители";
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 336);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(835, 259);
            this.dataGridView2.TabIndex = 19;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(834, 269);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(850, 610);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Добавить";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Location = new System.Drawing.Point(-4, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(851, 614);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.SystemColors.Info;
            this.tabPage5.Controls.Add(this.Clear_app);
            this.tabPage5.Controls.Add(this.phone);
            this.tabPage5.Controls.Add(this.adapp);
            this.tabPage5.Controls.Add(this.dob);
            this.tabPage5.Controls.Add(this.gender);
            this.tabPage5.Controls.Add(this.adress);
            this.tabPage5.Controls.Add(this.label10);
            this.tabPage5.Controls.Add(this.label9);
            this.tabPage5.Controls.Add(this.label4);
            this.tabPage5.Controls.Add(this.label3);
            this.tabPage5.Controls.Add(this.name);
            this.tabPage5.Controls.Add(this.label2);
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(843, 588);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Заявителя";
            // 
            // Clear_app
            // 
            this.Clear_app.Location = new System.Drawing.Point(300, 333);
            this.Clear_app.Name = "Clear_app";
            this.Clear_app.Size = new System.Drawing.Size(96, 23);
            this.Clear_app.TabIndex = 28;
            this.Clear_app.Text = "Очистить строки";
            this.Clear_app.UseVisualStyleBackColor = true;
            this.Clear_app.Click += new System.EventHandler(this.Clear_app_Click);
            // 
            // phone
            // 
            this.phone.Location = new System.Drawing.Point(395, 292);
            this.phone.Mask = "+7 (999) 000-0000";
            this.phone.Name = "phone";
            this.phone.Size = new System.Drawing.Size(166, 20);
            this.phone.TabIndex = 15;
            // 
            // adapp
            // 
            this.adapp.Location = new System.Drawing.Point(465, 333);
            this.adapp.Name = "adapp";
            this.adapp.Size = new System.Drawing.Size(96, 23);
            this.adapp.TabIndex = 14;
            this.adapp.Text = "Подтвердить";
            this.adapp.UseVisualStyleBackColor = true;
            this.adapp.Click += new System.EventHandler(this.Adapp_Click);
            // 
            // dob
            // 
            this.dob.Location = new System.Drawing.Point(395, 175);
            this.dob.MaxDate = new System.DateTime(9998, 5, 6, 0, 0, 0, 0);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(166, 20);
            this.dob.TabIndex = 13;
            this.dob.Value = new System.DateTime(2024, 5, 6, 0, 0, 0, 0);
            // 
            // gender
            // 
            this.gender.FormattingEnabled = true;
            this.gender.Items.AddRange(new object[] {
            "Мужской",
            "Женский"});
            this.gender.Location = new System.Drawing.Point(395, 210);
            this.gender.Name = "gender";
            this.gender.Size = new System.Drawing.Size(166, 30);
            this.gender.TabIndex = 12;
            // 
            // adress
            // 
            this.adress.Location = new System.Drawing.Point(395, 251);
            this.adress.Name = "adress";
            this.adress.Size = new System.Drawing.Size(166, 20);
            this.adress.TabIndex = 10;
            this.adress.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.adress_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(296, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Номер телефона:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(283, 258);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Адрес проживания:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(359, 214);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Пол:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(297, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Дата  рождения:";
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(395, 138);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(166, 20);
            this.name.TabIndex = 2;
            this.name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.name_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(352, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "ФИО:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(278, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(295, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Внесите данные для добавления";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.SystemColors.Info;
            this.tabPage6.Controls.Add(this.Clear_pas);
            this.tabPage6.Controls.Add(this.number);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.apid);
            this.tabPage6.Controls.Add(this.adpas);
            this.tabPage6.Controls.Add(this.expiration);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Controls.Add(this.type);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Controls.Add(this.issue);
            this.tabPage6.Controls.Add(this.label11);
            this.tabPage6.Controls.Add(this.label12);
            this.tabPage6.Controls.Add(this.label13);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(843, 588);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Паспорт";
            // 
            // Clear_pas
            // 
            this.Clear_pas.Location = new System.Drawing.Point(316, 301);
            this.Clear_pas.Name = "Clear_pas";
            this.Clear_pas.Size = new System.Drawing.Size(96, 23);
            this.Clear_pas.TabIndex = 27;
            this.Clear_pas.Text = "Очистить строки";
            this.Clear_pas.UseVisualStyleBackColor = true;
            this.Clear_pas.Click += new System.EventHandler(this.Clear_pas_Click);
            // 
            // number
            // 
            this.number.Location = new System.Drawing.Point(392, 130);
            this.number.Mask = "00-00-000000";
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(166, 20);
            this.number.TabIndex = 26;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(308, 265);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(78, 13);
            this.label27.TabIndex = 25;
            this.label27.Text = "ID Заявителя:";
            // 
            // apid
            // 
            this.apid.Location = new System.Drawing.Point(392, 262);
            this.apid.Name = "apid";
            this.apid.Size = new System.Drawing.Size(166, 20);
            this.apid.TabIndex = 24;
            // 
            // adpas
            // 
            this.adpas.Location = new System.Drawing.Point(462, 301);
            this.adpas.Name = "adpas";
            this.adpas.Size = new System.Drawing.Size(96, 23);
            this.adpas.TabIndex = 23;
            this.adpas.Text = "Подтвердить";
            this.adpas.UseVisualStyleBackColor = true;
            this.adpas.Click += new System.EventHandler(this.Adpas_Click);
            // 
            // expiration
            // 
            this.expiration.Cursor = System.Windows.Forms.Cursors.No;
            this.expiration.Enabled = false;
            this.expiration.Location = new System.Drawing.Point(392, 232);
            this.expiration.Name = "expiration";
            this.expiration.Size = new System.Drawing.Size(166, 20);
            this.expiration.TabIndex = 22;
            this.expiration.Value = new System.DateTime(2028, 4, 19, 12, 37, 0, 0);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(291, 239);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 13);
            this.label15.TabIndex = 21;
            this.label15.Text = "Действителен до:";
            // 
            // type
            // 
            this.type.FormattingEnabled = true;
            this.type.Items.AddRange(new object[] {
            "Обычный",
            "Заграничный"});
            this.type.Location = new System.Drawing.Point(392, 166);
            this.type.Name = "type";
            this.type.Size = new System.Drawing.Size(166, 30);
            this.type.TabIndex = 20;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(310, 170);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 13);
            this.label14.TabIndex = 19;
            this.label14.Text = "Тип паспорта:";
            // 
            // issue
            // 
            this.issue.Location = new System.Drawing.Point(392, 204);
            this.issue.Name = "issue";
            this.issue.Size = new System.Drawing.Size(166, 20);
            this.issue.TabIndex = 18;
            this.issue.ValueChanged += new System.EventHandler(this.issue_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(313, 210);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 13);
            this.label11.TabIndex = 17;
            this.label11.Text = "Дата выдачи:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(299, 133);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(87, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "Серия и Номер:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(280, 93);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(295, 20);
            this.label13.TabIndex = 14;
            this.label13.Text = "Внесите данные для добавления";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.tabControl3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(850, 610);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Изменить";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Controls.Add(this.tabPage8);
            this.tabControl3.Location = new System.Drawing.Point(0, 0);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(847, 614);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.SystemColors.Info;
            this.tabPage7.Controls.Add(this.phone_chan);
            this.tabPage7.Controls.Add(this.СlearChanApp);
            this.tabPage7.Controls.Add(this.label28);
            this.tabPage7.Controls.Add(this.id);
            this.tabPage7.Controls.Add(this.ChanApp);
            this.tabPage7.Controls.Add(this.dob_chan);
            this.tabPage7.Controls.Add(this.gender_chan);
            this.tabPage7.Controls.Add(this.adress_chan);
            this.tabPage7.Controls.Add(this.label18);
            this.tabPage7.Controls.Add(this.label19);
            this.tabPage7.Controls.Add(this.label20);
            this.tabPage7.Controls.Add(this.label21);
            this.tabPage7.Controls.Add(this.name_chan);
            this.tabPage7.Controls.Add(this.label22);
            this.tabPage7.Controls.Add(this.label17);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(839, 588);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Заявителя";
            // 
            // phone_chan
            // 
            this.phone_chan.Location = new System.Drawing.Point(380, 320);
            this.phone_chan.Mask = "+7 (999) 000-0000";
            this.phone_chan.Name = "phone_chan";
            this.phone_chan.Size = new System.Drawing.Size(166, 20);
            this.phone_chan.TabIndex = 31;
            // 
            // СlearChanApp
            // 
            this.СlearChanApp.Location = new System.Drawing.Point(273, 351);
            this.СlearChanApp.Name = "СlearChanApp";
            this.СlearChanApp.Size = new System.Drawing.Size(96, 23);
            this.СlearChanApp.TabIndex = 30;
            this.СlearChanApp.Text = "Очистить";
            this.СlearChanApp.UseVisualStyleBackColor = true;
            this.СlearChanApp.Click += new System.EventHandler(this.СlearChanApp_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(469, 175);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(18, 13);
            this.label28.TabIndex = 28;
            this.label28.Text = "ID";
            // 
            // id
            // 
            this.id.Enabled = false;
            this.id.Location = new System.Drawing.Point(493, 170);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(53, 20);
            this.id.TabIndex = 27;
      
            // 
            // ChanApp
            // 
            this.ChanApp.Location = new System.Drawing.Point(450, 351);
            this.ChanApp.Name = "ChanApp";
            this.ChanApp.Size = new System.Drawing.Size(96, 23);
            this.ChanApp.TabIndex = 25;
            this.ChanApp.Text = "Подтвердить";
            this.ChanApp.UseVisualStyleBackColor = true;
            this.ChanApp.Click += new System.EventHandler(this.ChanApp_Click);
            // 
            // dob_chan
            // 
            this.dob_chan.Location = new System.Drawing.Point(380, 226);
            this.dob_chan.Name = "dob_chan";
            this.dob_chan.Size = new System.Drawing.Size(166, 20);
            this.dob_chan.TabIndex = 24;
            // 
            // gender_chan
            // 
            this.gender_chan.FormattingEnabled = true;
            this.gender_chan.Items.AddRange(new object[] {
            "Мужской",
            "Женский"});
            this.gender_chan.Location = new System.Drawing.Point(380, 252);
            this.gender_chan.Name = "gender_chan";
            this.gender_chan.Size = new System.Drawing.Size(166, 30);
            this.gender_chan.TabIndex = 23;
            // 
            // adress_chan
            // 
            this.adress_chan.Location = new System.Drawing.Point(380, 290);
            this.adress_chan.Name = "adress_chan";
            this.adress_chan.Size = new System.Drawing.Size(166, 20);
            this.adress_chan.TabIndex = 21;
            this.adress_chan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.adress_chan_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(280, 323);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(96, 13);
            this.label18.TabIndex = 20;
            this.label18.Text = "Номер телефона:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(270, 297);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(106, 13);
            this.label19.TabIndex = 19;
            this.label19.Text = "Адрес проживания:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(346, 269);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(30, 13);
            this.label20.TabIndex = 18;
            this.label20.Text = "Пол:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(284, 232);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(92, 13);
            this.label21.TabIndex = 17;
            this.label21.Text = "Дата  рождения:";
            // 
            // name_chan
            // 
            this.name_chan.Location = new System.Drawing.Point(380, 196);
            this.name_chan.Name = "name_chan";
            this.name_chan.Size = new System.Drawing.Size(166, 20);
            this.name_chan.TabIndex = 16;
            this.name_chan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.name_chan_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(339, 203);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(37, 13);
            this.label22.TabIndex = 15;
            this.label22.Text = "ФИО:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(60, 107);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(731, 20);
            this.label17.TabIndex = 1;
            this.label17.Text = "Нажмите два раза на строку в окне \"Таблицы\" чтобы изменить данные о заявителе.";
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.SystemColors.Info;
            this.tabPage8.Controls.Add(this.label29);
            this.tabPage8.Controls.Add(this.apid_chan);
            this.tabPage8.Controls.Add(this.ClearChanPass);
            this.tabPage8.Controls.Add(this.number_chan);
            this.tabPage8.Controls.Add(this.ChanPass);
            this.tabPage8.Controls.Add(this.issue_chan);
            this.tabPage8.Controls.Add(this.label23);
            this.tabPage8.Controls.Add(this.type_chan);
            this.tabPage8.Controls.Add(this.label24);
            this.tabPage8.Controls.Add(this.expiration_chan);
            this.tabPage8.Controls.Add(this.label25);
            this.tabPage8.Controls.Add(this.label26);
            this.tabPage8.Controls.Add(this.label16);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(839, 588);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "Паспорт";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(401, 333);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(78, 13);
            this.label29.TabIndex = 37;
            this.label29.Text = "ID Заявителя:";
            // 
            // apid_chan
            // 
            this.apid_chan.Enabled = false;
            this.apid_chan.Location = new System.Drawing.Point(485, 330);
            this.apid_chan.Name = "apid_chan";
            this.apid_chan.Size = new System.Drawing.Size(46, 20);
            this.apid_chan.TabIndex = 36;
            // 
            // ClearChanPass
            // 
            this.ClearChanPass.Location = new System.Drawing.Point(267, 356);
            this.ClearChanPass.Name = "ClearChanPass";
            this.ClearChanPass.Size = new System.Drawing.Size(96, 23);
            this.ClearChanPass.TabIndex = 35;
            this.ClearChanPass.Text = "Очистить";
            this.ClearChanPass.UseVisualStyleBackColor = true;
            this.ClearChanPass.Click += new System.EventHandler(this.ClearChanPass_Click);
            // 
            // number_chan
            // 
            this.number_chan.Location = new System.Drawing.Point(365, 177);
            this.number_chan.Mask = "00-00-000000";
            this.number_chan.Name = "number_chan";
            this.number_chan.Size = new System.Drawing.Size(166, 20);
            this.number_chan.TabIndex = 33;
            // 
            // ChanPass
            // 
            this.ChanPass.Location = new System.Drawing.Point(435, 356);
            this.ChanPass.Name = "ChanPass";
            this.ChanPass.Size = new System.Drawing.Size(96, 23);
            this.ChanPass.TabIndex = 32;
            this.ChanPass.Text = "Подтвердить";
            this.ChanPass.UseVisualStyleBackColor = true;
            this.ChanPass.Click += new System.EventHandler(this.ChanPass_Click);
            // 
            // issue_chan
            // 
            this.issue_chan.Location = new System.Drawing.Point(365, 251);
            this.issue_chan.Name = "issue_chan";
            this.issue_chan.Size = new System.Drawing.Size(166, 20);
            this.issue_chan.TabIndex = 31;
            this.issue_chan.ValueChanged += new System.EventHandler(this.issue_chan_ValueChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(264, 302);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(98, 13);
            this.label23.TabIndex = 30;
            this.label23.Text = "Действителен до:";
            // 
            // type_chan
            // 
            this.type_chan.FormattingEnabled = true;
            this.type_chan.Items.AddRange(new object[] {
            "Обычный",
            "Заграничный"});
            this.type_chan.Location = new System.Drawing.Point(365, 213);
            this.type_chan.Name = "type_chan";
            this.type_chan.Size = new System.Drawing.Size(166, 30);
            this.type_chan.TabIndex = 29;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(283, 217);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(79, 13);
            this.label24.TabIndex = 28;
            this.label24.Text = "Тип паспорта:";
            // 
            // expiration_chan
            // 
            this.expiration_chan.Enabled = false;
            this.expiration_chan.Location = new System.Drawing.Point(365, 295);
            this.expiration_chan.Name = "expiration_chan";
            this.expiration_chan.Size = new System.Drawing.Size(166, 20);
            this.expiration_chan.TabIndex = 27;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(286, 257);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(76, 13);
            this.label25.TabIndex = 26;
            this.label25.Text = "Дата выдачи:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(272, 180);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(87, 13);
            this.label26.TabIndex = 24;
            this.label26.Text = "Серия и Номер:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label16.Location = new System.Drawing.Point(64, 112);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(725, 20);
            this.label16.TabIndex = 0;
            this.label16.Text = "Нажмите  два раза на строку в окне \"Таблицы\" чтобы изменить данные о паспорте.";
            // 
            // exit
            // 
            this.exit.AutoSize = true;
            this.exit.BackColor = System.Drawing.Color.Red;
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exit.Location = new System.Drawing.Point(816, 2);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(25, 23);
            this.exit.TabIndex = 34;
            this.exit.Text = "X";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // info
            // 
            this.info.AutoSize = true;
            this.info.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.info.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.info.Location = new System.Drawing.Point(817, 309);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(24, 23);
            this.info.TabIndex = 35;
            this.info.Text = "?";
            this.info.UseVisualStyleBackColor = false;
            this.info.Click += new System.EventHandler(this.info_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(859, 637);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Паспортный Стол";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button updpass;
        private System.Windows.Forms.Button updapp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox adress;
        private System.Windows.Forms.ListBox gender;
        private System.Windows.Forms.DateTimePicker dob;
        private System.Windows.Forms.Button adapp;
        private System.Windows.Forms.ListBox type;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker issue;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker expiration;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button adpas;
        private System.Windows.Forms.Button delpass;
        private System.Windows.Forms.Button delapp;
        private System.Windows.Forms.Button ChanApp;
        private System.Windows.Forms.DateTimePicker dob_chan;
        private System.Windows.Forms.ListBox gender_chan;
        private System.Windows.Forms.TextBox adress_chan;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox name_chan;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button ChanPass;
        private System.Windows.Forms.DateTimePicker issue_chan;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ListBox type_chan;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DateTimePicker expiration_chan;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button SearchPass;
        private System.Windows.Forms.Button searchApp;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox apid;
        private System.Windows.Forms.MaskedTextBox phone;
        private System.Windows.Forms.MaskedTextBox number;
        private System.Windows.Forms.MaskedTextBox number_chan;
        private System.Windows.Forms.Button Clear_pas;
        private System.Windows.Forms.Button Clear_app;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.Button СlearChanApp;
        private System.Windows.Forms.Button ClearChanPass;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox apid_chan;
        private System.Windows.Forms.MaskedTextBox phone_chan;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button info;
    }
}

